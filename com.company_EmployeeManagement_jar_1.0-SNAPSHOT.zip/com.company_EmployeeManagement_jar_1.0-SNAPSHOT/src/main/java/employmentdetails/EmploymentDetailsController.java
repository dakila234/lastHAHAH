
package employmentdetails;

import db.DB;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class EmploymentDetailsController {

    EmploymentDetailsView edv;

    private DefaultTableModel tableModel;

    // CONSTRUCTOR
    public EmploymentDetailsController(EmploymentDetailsView temp1) {

        edv = temp1;

        // TABLE COLUMNS - NO ID COLUMN
        tableModel = new DefaultTableModel(
                new String[]{
                    "Employee ID",
                    "Job Position",
                    "Salary",
                    "Employment Status",
                    "Hired Date"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Sets the table model.
        edv.employmentTable.setModel(tableModel);

        // Allows only one row to be selected.
        edv.employmentTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        // Registers button actions.
        edv.allListeners(new AllActions());

        // Loads employment records.
        loadEmploymentTable();

        // TABLE SELECTION LISTENER
        // Displays the selected row's Employee ID in txtEmployeeID.
        edv.employmentTable.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {

                        int row = edv.employmentTable.getSelectedRow();

                        if (row >= 0) {

                            String employeeID =
                                    tableModel.getValueAt(row, 0).toString();

                            edv.txtEmployeeID.setText(employeeID);

                            // Loads the selected employee's details.
                            loadSelectedDetails();
                        }
                    }
                });
    }

    // LOAD EMPLOYMENT TABLE
    private void loadEmploymentTable() {

        tableModel.setRowCount(0);

        String sql = "SELECT employeeID, job_position, salary, "
                + "employment_status, hire_date "
                + "FROM employment_details "
                + "ORDER BY employeeID";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                tableModel.addRow(new Object[]{
                    rs.getString("employeeID"),
                    rs.getString("job_position"),
                    rs.getBigDecimal("salary"),
                    rs.getString("employment_status"),
                    rs.getDate("hire_date")
                });
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // GET EMPLOYEE ID FROM TEXT FIELD
    private String getSelectedEmployeeID() {

        // Gets the Employee ID typed by the user.
        String employeeID = edv.txtEmployeeID.getText().trim();

        // Returns null if the field is empty.
        return employeeID.isEmpty() ? null : employeeID;
    }

    // READ EMPLOYMENT DETAILS
    private void loadSelectedDetails() {

        String employeeID = getSelectedEmployeeID();

        if (employeeID == null) {
            clearEmploymentFields();
            return;
        }

        // Gets employment details from the DAO.
        EmploymentDetails em = EmploymentDetailsDAO.read(employeeID);

        if (em == null) {
            clearEmploymentFields();
            return;
        }

        // Displays the retrieved information.
        edv.jTextField2.setText(em.getJob_position());

        edv.jTextField3.setText(
                em.getSalary() == null
                        ? ""
                        : em.getSalary().toString()
        );

        edv.jTextField4.setText(em.getEmployment_status());

        edv.jTextField5.setText(
                em.getHire_date() == null
                        ? ""
                        : em.getHire_date().toString()
        );
    }

    // CLEAR EMPLOYMENT FIELDS
    private void clearEmploymentFields() {

        edv.jTextField2.setText("");
        edv.jTextField3.setText("");
        edv.jTextField4.setText("");
        edv.jTextField5.setText("");
    }

    // CLEAR ALL FIELDS
    private void clearFields() {

        edv.txtEmployeeID.setText("");
        clearEmploymentFields();
    }

    // GET FORM DETAILS
    private EmploymentDetails getFormDetails() {

        // Gets Employee ID from txtEmployeeID.
        String employeeID = getSelectedEmployeeID();

        if (employeeID == null) {

            JOptionPane.showMessageDialog(
                    edv, "Please enter an Employee ID."
            );

            return null;
        }

        String jobPosition = edv.jTextField2.getText().trim();
        String salaryText = edv.jTextField3.getText().trim();
        String employmentStatus = edv.jTextField4.getText().trim();
        String hireDateText = edv.jTextField5.getText().trim();

        // Checks whether required fields are empty.
        if (jobPosition.isEmpty()
                || salaryText.isEmpty()
                || employmentStatus.isEmpty()
                || hireDateText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    edv, "Please fill in all fields."
            );

            return null;
        }

        try {

            // Converts salary text into BigDecimal.
            BigDecimal salary = new BigDecimal(salaryText);

            if (salary.compareTo(BigDecimal.ZERO) < 0) {

                JOptionPane.showMessageDialog(
                        edv, "Salary cannot be negative."
                );

                return null;
            }

            // Converts the date text into LocalDate.
            LocalDate hireDate = LocalDate.parse(hireDateText);

            // Creates the model object.
            EmploymentDetails em = new EmploymentDetails();

            // Stores the form values in the model.
            em.setEmployeeID(employeeID);
            em.setJob_position(jobPosition);
            em.setSalary(salary);
            em.setEmployment_status(employmentStatus);
            em.setHire_date(hireDate);

            return em;

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    edv, "Salary must be a valid number."
            );

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    edv, "Hire date must use YYYY-MM-DD format."
            );
        }

        return null;
    }

    // CLEAR FORM
    private void clearForm() {

        clearFields();
        edv.employmentTable.clearSelection();
    }

    // DISPLAY DATABASE ERRORS
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                edv,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // BUTTON ACTIONS
    class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            // REFRESH BUTTON
            if (source == edv.refreshBTN2) {

                loadEmploymentTable();
                clearForm();

                JOptionPane.showMessageDialog(
                        edv, "Employment details refreshed!"
                );

                return;
            }

            // READ BUTTON
            if (source == edv.readBTN2) {

                loadSelectedDetails();
                loadEmploymentTable();

                return;
            }

            // SAVE BUTTON
            if (source == edv.saveBTN2) {

                EmploymentDetails em = getFormDetails();

                if (em != null && EmploymentDetailsDAO.save(em)) {

                    loadEmploymentTable();
                    loadSelectedDetails();
                }

                return;
            }

            // UPDATE BUTTON
            if (source == edv.updateBTN2) {

                EmploymentDetails em = getFormDetails();

                if (em != null) {

                    int choice = JOptionPane.showConfirmDialog(
                            edv,
                            "Update employment details for "
                            + em.getEmployeeID() + "?",
                            "Confirm Update",
                            JOptionPane.YES_NO_OPTION
                    );

                    if (choice == JOptionPane.YES_OPTION) {

                        if (EmploymentDetailsDAO.update(em)) {

                            loadEmploymentTable();
                            loadSelectedDetails();
                        }
                    }
                }

                return;
            }

            // DELETE BUTTON
            if (source == edv.deleteBTN2) {

                String employeeID = getSelectedEmployeeID();

                if (employeeID == null) {

                    JOptionPane.showMessageDialog(
                            edv, "Please enter an Employee ID."
                    );

                    return;
                }

                int choice = JOptionPane.showConfirmDialog(
                        edv,
                        "Delete employment details for "
                        + employeeID + "?\n"
                        + "The employee record itself will not be deleted.",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {

                    if (EmploymentDetailsDAO.delete(employeeID)) {

                        clearForm();
                        loadEmploymentTable();
                    }
                }
            }
        }
    }
}
