
package attendance;

import db.DB;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class AttendanceController {

    AttendanceView av;
    private final DefaultTableModel tableModel;

    // CONSTRUCTOR
    public AttendanceController(AttendanceView temp1) {

        av = temp1;

        // TABLE COLUMNS - NO ID COLUMN
        tableModel = new DefaultTableModel(
                new String[]{
                    "Employee ID",
                    "Work Date",
                    "Shift",
                    "Login Time",
                    "Logout Time",
                    "Status"
                }, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Connects the table model to the JTable.
        av.attendanceTable.setModel(tableModel);

        // Allows only one row to be selected.
        av.attendanceTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        // Registers button actions.
        av.allListeners(new AllActions());

        // Loads attendance records.
        loadAttendanceTable();

        // TABLE SELECTION LISTENER
        // Displays the selected row's information in the form.
        av.attendanceTable.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {
                        fillFieldsFromSelectedRow();
                    }
                });
    }

    // LOAD ATTENDANCE TABLE
    private void loadAttendanceTable() {

        // Removes old rows before loading updated records.
        tableModel.setRowCount(0);

        String sql = "SELECT employeeID, work_date, shift, "
                + "login_time, logout_time, status "
                + "FROM attendance "
                + "ORDER BY work_date DESC, employeeID";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Reads each attendance record.
            while (rs.next()) {

                // Adds database values to the JTable.
                tableModel.addRow(new Object[]{
                    rs.getString("employeeID"),
                    rs.getDate("work_date"),
                    rs.getString("shift"),
                    rs.getTime("login_time"),
                    rs.getTime("logout_time"),
                    rs.getString("status")
                });
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // GET EMPLOYEE ID FROM TEXT FIELD
    private String getEmployeeID() {

        // Gets the Employee ID entered by the user.
        String employeeID = av.txtEmployeeID.getText().trim();

        // Returns null if the field is empty.
        return employeeID.isEmpty() ? null : employeeID;
    }

    // FILL FIELDS WHEN SELECTING A TABLE ROW
    private void fillFieldsFromSelectedRow() {

        int row = av.attendanceTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        // Column 0 = Employee ID
        av.txtEmployeeID.setText(
                tableModel.getValueAt(row, 0).toString());

        // Column 1 = Work Date
        av.jTextField2.setText(
                tableModel.getValueAt(row, 1).toString());

        // Column 2 = Shift
        av.jTextField3.setText(
                tableModel.getValueAt(row, 2).toString());

        // Column 3 = Login Time
        av.jTextField4.setText(
                tableModel.getValueAt(row, 3) == null
                ? "" : tableModel.getValueAt(row, 3).toString());

        // Column 4 = Logout Time
        av.jTextField5.setText(
                tableModel.getValueAt(row, 4) == null
                ? "" : tableModel.getValueAt(row, 4).toString());

        // Column 5 = Status
        av.jTextField6.setText(
                tableModel.getValueAt(row, 5).toString());
    }

    // VALIDATE FIELDS
    private boolean validateFields() {

        // Checks whether Employee ID is entered.
        String employeeID = getEmployeeID();

        if (employeeID == null) {
            JOptionPane.showMessageDialog(
                    av, "Please enter an Employee ID.");
            return false;
        }

        // Checks required fields.
        if (av.jTextField2.getText().trim().isEmpty()
                || av.jTextField3.getText().trim().isEmpty()
                || av.jTextField6.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    av,
                    "Please fill in Work Date, Shift, and Status.");

            return false;
        }

        // Checks whether the Employee ID exists in employees.
        String sql = "SELECT employeeID FROM employees WHERE employeeID = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, employeeID);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(
                            av, "Employee ID does not exist.");
                    return false;
                }
            }

        } catch (SQLException ex) {
            showError(ex);
            return false;
        }

        // Validates date and time formats.
        try {

            LocalDate.parse(av.jTextField2.getText().trim());

            if (!av.jTextField4.getText().trim().isEmpty()) {
                LocalTime.parse(av.jTextField4.getText().trim());
            }

            if (!av.jTextField5.getText().trim().isEmpty()) {
                LocalTime.parse(av.jTextField5.getText().trim());
            }

        } catch (DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    av,
                    "Invalid date or time format.\n"
                    + "Date: YYYY-MM-DD\n"
                    + "Time: HH:MM:SS (24-hour format)");

            return false;
        }

        return true;
    }

    // GET FORM DATA
    private AttendanceDetails getFormDetails() {

        AttendanceDetails attendance = new AttendanceDetails();

        // Gets Employee ID from the JTextField.
        attendance.setEmployeeID(getEmployeeID());

        attendance.setWork_date(
                LocalDate.parse(av.jTextField2.getText().trim()));

        attendance.setShift(
                av.jTextField3.getText().trim());

        String login = av.jTextField4.getText().trim();

        // Converts login time into LocalTime.
        // If empty, stores null.
        attendance.setLogin_time(
                login.isEmpty() ? null : LocalTime.parse(login));

        String logout = av.jTextField5.getText().trim();

        // Converts logout time into LocalTime.
        // If empty, stores null.
        attendance.setLogout_time(
                logout.isEmpty() ? null : LocalTime.parse(logout));

        attendance.setStatus(
                av.jTextField6.getText().trim());

        return attendance;
    }

    // SAVE ATTENDANCE
    private void saveAttendance() {

        if (!validateFields()) {
            return;
        }

        AttendanceDetails attendance = getFormDetails();

        String sql = "INSERT INTO attendance "
                + "(employeeID, work_date, shift, login_time, logout_time, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            setAttendanceParameters(ps, attendance);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                    av, "Attendance added!");

            loadAttendanceTable();
            clearFields();

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // READ ATTENDANCE
    private void readAttendance() {

        loadAttendanceTable();

        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                    av, "No attendance records found.");
        }
    }

    // REFRESH ATTENDANCE
    private void refreshAttendance() {

        loadAttendanceTable();
        clearFields();

        JOptionPane.showMessageDialog(
                av, "Attendance table refreshed!");
    }

    // UPDATE ATTENDANCE
    private void updateAttendance() {

        int row = av.attendanceTable.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(
                    av, "Select an attendance row first.");
            return;
        }

        if (!validateFields()) {
            return;
        }

        // Gets the original record values.
        String oldEmployeeID =
                tableModel.getValueAt(row, 0).toString();

        LocalDate oldWorkDate =
                LocalDate.parse(tableModel.getValueAt(row, 1).toString());

        int choice = JOptionPane.showConfirmDialog(
                av,
                "Update the selected attendance record?",
                "Confirm Update",
                JOptionPane.YES_NO_OPTION);

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        AttendanceDetails attendance = getFormDetails();

        // Uses the original Employee ID and Work Date
        // to identify the record being updated.
        String sql = "UPDATE attendance SET employeeID = ?, "
                + "work_date = ?, shift = ?, login_time = ?, "
                + "logout_time = ?, status = ? "
                + "WHERE employeeID = ? AND work_date = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            setAttendanceParameters(ps, attendance);

            ps.setString(7, oldEmployeeID);
            ps.setDate(8, java.sql.Date.valueOf(oldWorkDate));

            if (ps.executeUpdate() > 0) {

                JOptionPane.showMessageDialog(
                        av, "Attendance updated!");

                loadAttendanceTable();
                clearFields();

            } else {
                JOptionPane.showMessageDialog(
                        av, "No record was updated.");
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // DELETE ATTENDANCE
    private void deleteAttendance() {

        int row = av.attendanceTable.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(
                    av, "Select an attendance row first.");
            return;
        }

        // Gets the selected record information.
        String employeeID =
                tableModel.getValueAt(row, 0).toString();

        LocalDate workDate =
                LocalDate.parse(tableModel.getValueAt(row, 1).toString());

        int choice = JOptionPane.showConfirmDialog(
                av,
                "Delete the selected attendance record?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM attendance "
                + "WHERE employeeID = ? AND work_date = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, employeeID);
            ps.setDate(2, java.sql.Date.valueOf(workDate));

            if (ps.executeUpdate() > 0) {

                JOptionPane.showMessageDialog(
                        av, "Attendance deleted!");

                loadAttendanceTable();
                clearFields();

            } else {
                JOptionPane.showMessageDialog(
                        av, "No record was deleted.");
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // SET SQL PARAMETERS
    private void setAttendanceParameters(
            PreparedStatement ps,
            AttendanceDetails attendance) throws SQLException {

        ps.setString(1, attendance.getEmployeeID());

        ps.setDate(2, java.sql.Date.valueOf(
                attendance.getWork_date()));

        ps.setString(3, attendance.getShift());

        // Stores NULL if login time is empty.
        if (attendance.getLogin_time() == null) {
            ps.setNull(4, java.sql.Types.TIME);
        } else {
            ps.setTime(4, java.sql.Time.valueOf(
                    attendance.getLogin_time()));
        }

        // Stores NULL if logout time is empty.
        if (attendance.getLogout_time() == null) {
            ps.setNull(5, java.sql.Types.TIME);
        } else {
            ps.setTime(5, java.sql.Time.valueOf(
                    attendance.getLogout_time()));
        }

        ps.setString(6, attendance.getStatus());
    }

    // CLEAR FIELDS
    private void clearFields() {

        av.txtEmployeeID.setText("");
        av.jTextField2.setText("");
        av.jTextField3.setText("");
        av.jTextField4.setText("");
        av.jTextField5.setText("");
        av.jTextField6.setText("");

        // Removes the selected table row.
        av.attendanceTable.clearSelection();
    }

    // SHOW DATABASE ERRORS
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                av,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
    }

    // BUTTON ACTIONS
    class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            if (source == av.saveBTN4) {
                saveAttendance();

            } else if (source == av.readBTN4) {
                readAttendance();

            } else if (source == av.updateBTN4) {
                updateAttendance();

            } else if (source == av.deleteBTN4) {
                deleteAttendance();

            } else if (source == av.refreshBTN4) {
                refreshAttendance();
            }
        }
    }
}
