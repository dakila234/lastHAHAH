
package employee;

import db.DB;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class EmployeeController {

    private EmployeeView ev;
    private EmployeeDAO dao = new EmployeeDAO();

    public EmployeeController(EmployeeView temp) {
        ev = temp;

        ev.allListeners(new AllActions());

        // TABLE COLUMNS - NO ID COLUMN
        ev.employeeTable.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Employee ID",
                    "First Name",
                    "Last Name",
                    "Birthday",
                    "Age",
                    "Email",
                    "Phone",
                    "Address"
                }
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        ev.employeeTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        loadEmployeeTable();
    }

    // LOAD EMPLOYEE TABLE
    private void loadEmployeeTable() {

        DefaultTableModel model =
                (DefaultTableModel) ev.employeeTable.getModel();

        model.setRowCount(0);

        // Removed id from SELECT statement
        String sql = "SELECT employeeID, first_name, last_name, "
                + "birthday, email, phone, address FROM employees";

        try (Connection con = DB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {

                LocalDate birthday = null;

                if (rs.getDate("birthday") != null) {
                    birthday = rs.getDate("birthday").toLocalDate();
                }

                // Calculate age using birthday
                int age = 0;

                if (birthday != null) {
                    age = Period.between(
                            birthday,
                            LocalDate.now()
                    ).getYears();
                }

                // Add employee information to JTable
                model.addRow(new Object[]{
                    rs.getString("employeeID"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    birthday,
                    age,
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("address")
                });
            }

        } catch (SQLException e) {
            showError(e);
        }
    }

    // READ EMPLOYEE
    private void readEmployee() {

        String employeeID = ev.jTextField1.getText().trim();

        if (employeeID.isEmpty()) {
            JOptionPane.showMessageDialog(
                    ev,
                    "Enter Employee ID first!"
            );
            return;
        }

        String sql = "SELECT * FROM employees WHERE employeeID = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, employeeID);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {

                    ev.jTextField2.setText(rs.getString("first_name"));
                    ev.jTextField3.setText(rs.getString("last_name"));

                    if (rs.getDate("birthday") != null) {
                        ev.jTextField4.setText(
                                rs.getDate("birthday").toString()
                        );
                    } else {
                        ev.jTextField4.setText("");
                    }

                    ev.jTextField6.setText(rs.getString("email"));
                    ev.jTextField7.setText(rs.getString("phone"));
                    ev.jTextField8.setText(rs.getString("address"));

                } else {
                    JOptionPane.showMessageDialog(
                            ev,
                            "Employee not found!"
                    );
                }
            }

        } catch (SQLException e) {
            showError(e);
        }
    }

    // SAVE EMPLOYEE
    private void saveEmployee() {

        try {
            String employeeID = ev.jTextField1.getText().trim();
            String firstName = ev.jTextField2.getText().trim();
            String lastName = ev.jTextField3.getText().trim();
            String birthdayText = ev.jTextField4.getText().trim();
            String email = ev.jTextField6.getText().trim();
            String phone = ev.jTextField7.getText().trim();
            String address = ev.jTextField8.getText().trim();

            if (employeeID.isEmpty()
                    || firstName.isEmpty()
                    || lastName.isEmpty()) {

                JOptionPane.showMessageDialog(
                        ev,
                        "Employee ID, First Name, and Last Name are required!"
                );
                return;
            }

            LocalDate birthday = null;

            if (!birthdayText.isEmpty()) {
                birthday = LocalDate.parse(birthdayText);

                if (birthday.isAfter(LocalDate.now())) {
                    JOptionPane.showMessageDialog(
                            ev,
                            "Birthday cannot be in the future!"
                    );
                    return;
                }
            }

            Employee em = new Employee();

            em.setEmployeeID(employeeID);
            em.setFirst_name(firstName);
            em.setLast_name(lastName);
            em.setBirthday(birthday);
            em.setEmail(email);
            em.setPhone(phone);
            em.setAddress(address);

            dao.save(em);

            loadEmployeeTable();
            clearFields();

        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(
                    ev,
                    "Invalid birthday format! Use YYYY-MM-DD."
            );
        }
    }

    // UPDATE EMPLOYEE
    private void updateEmployee() {

        try {
            String employeeID = ev.jTextField1.getText().trim();
            String firstName = ev.jTextField2.getText().trim();
            String lastName = ev.jTextField3.getText().trim();
            String birthdayText = ev.jTextField4.getText().trim();
            String email = ev.jTextField6.getText().trim();
            String phone = ev.jTextField7.getText().trim();
            String address = ev.jTextField8.getText().trim();

            if (employeeID.isEmpty()) {
                JOptionPane.showMessageDialog(
                        ev,
                        "Enter Employee ID first!"
                );
                return;
            }

            if (firstName.isEmpty() || lastName.isEmpty()) {
                JOptionPane.showMessageDialog(
                        ev,
                        "First Name and Last Name are required!"
                );
                return;
            }

            LocalDate birthday = null;
            int age = 0;

            if (!birthdayText.isEmpty()) {
                birthday = LocalDate.parse(birthdayText);

                if (birthday.isAfter(LocalDate.now())) {
                    JOptionPane.showMessageDialog(
                            ev,
                            "Birthday cannot be in the future!"
                    );
                    return;
                }

                age = Period.between(
                        birthday,
                        LocalDate.now()
                ).getYears();
            }

            // Update using employeeID only
            String sql = "UPDATE employees SET first_name = ?, "
                    + "last_name = ?, birthday = ?, age = ?, "
                    + "email = ?, phone = ?, address = ? "
                    + "WHERE employeeID = ?";

            try (Connection con = DB.getConnection();
                 PreparedStatement pst = con.prepareStatement(sql)) {

                pst.setString(1, firstName);
                pst.setString(2, lastName);

                if (birthday != null) {
                    pst.setDate(
                            3,
                            java.sql.Date.valueOf(birthday)
                    );
                } else {
                    pst.setNull(3, java.sql.Types.DATE);
                }

                pst.setInt(4, age);
                pst.setString(5, email);
                pst.setString(6, phone);
                pst.setString(7, address);
                pst.setString(8, employeeID);

                int rows = pst.executeUpdate();

                if (rows > 0) {
                    JOptionPane.showMessageDialog(
                            ev,
                            "Employee updated successfully!"
                    );

                    loadEmployeeTable();
                    clearFields();

                } else {
                    JOptionPane.showMessageDialog(
                            ev,
                            "Employee not found!"
                    );
                }
            }

        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(
                    ev,
                    "Invalid birthday format! Use YYYY-MM-DD."
            );

        } catch (SQLException e) {
            showError(e);
        }
    }

    // DELETE EMPLOYEE
    private void deleteEmployee() {

        String employeeID = ev.jTextField1.getText().trim();

        if (employeeID.isEmpty()) {
            JOptionPane.showMessageDialog(
                    ev,
                    "Enter Employee ID first!"
            );
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                ev,
                "Are you sure you want to delete this employee?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        // Delete using employeeID only
        String sql = "DELETE FROM employees WHERE employeeID = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, employeeID);

            int rows = pst.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(
                        ev,
                        "Employee deleted successfully!"
                );

                loadEmployeeTable();
                clearFields();

            } else {
                JOptionPane.showMessageDialog(
                        ev,
                        "Employee not found!"
                );
            }

        } catch (SQLException e) {
            showError(e);
        }
    }

    // REFRESH EMPLOYEE TABLE AND CLEAR TEXT FIELDS
    private void refreshEmployee() {

        loadEmployeeTable();
        clearFields();

        JOptionPane.showMessageDialog(
                ev,
                "Employee table refreshed!"
        );
    }

    // CLEAR TEXT FIELDS
    private void clearFields() {

        ev.jTextField1.setText("");
        ev.jTextField2.setText("");
        ev.jTextField3.setText("");
        ev.jTextField4.setText("");
        ev.jTextField6.setText("");
        ev.jTextField7.setText("");
        ev.jTextField8.setText("");
    }

    // DISPLAY SQL ERROR
    private void showError(SQLException e) {

        JOptionPane.showMessageDialog(
                ev,
                "Database Error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // BUTTON ACTIONS
    class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            if (source == ev.saveBTN) {
                saveEmployee();

            } else if (source == ev.readBTN) {
                readEmployee();

            } else if (source == ev.updateBTN) {
                updateEmployee();

            } else if (source == ev.deleteBTN) {
                deleteEmployee();

            } else if (source == ev.refreshBTN) {
                refreshEmployee();
            }
        }
    }
}
