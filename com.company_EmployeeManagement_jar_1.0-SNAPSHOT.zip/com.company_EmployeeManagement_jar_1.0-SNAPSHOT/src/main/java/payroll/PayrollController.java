
package payroll;

import db.DB;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class PayrollController {

    PayrollView pv;

    private final DefaultTableModel tableModel;

    // CONSTRUCTOR
    public PayrollController(PayrollView temp1) {

        pv = temp1;

        // TABLE COLUMNS - NO ID COLUMN
        tableModel = new DefaultTableModel(
                new String[]{
                    "Employee ID",
                    "Pay Date",
                    "Pay Period",
                    "Daily Rate",
                    "Days Worked",
                    "Basic Salary",
                    "Overtime Pay",
                    "Gross Salary",
                    "Deductions",
                    "Net Salary",
                    "Payment Status"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Sets the JTable model.
        pv.payrollTable.setModel(tableModel);

        // Allows only one row to be selected.
        pv.payrollTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        // Registers button actions.
        pv.allListeners(new AllActions());

        // Loads payroll records.
        loadPayrollTable();

        // TABLE SELECTION LISTENER
        // Displays selected payroll information in the form.
        pv.payrollTable.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {
                fillFieldsFromSelectedRow();
            }
        });
    }

    // LOAD PAYROLL TABLE
    private void loadPayrollTable() {

        // Removes old rows before loading updated records.
        tableModel.setRowCount(0);

        String sql = "SELECT employeeID, pay_date, pay_period, "
                + "daily_rate, days_worked, basic_salary, "
                + "overtime_pay, gross_salary, deductions, "
                + "net_salary, payment_status "
                + "FROM payroll "
                + "ORDER BY pay_date DESC, employeeID";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Reads each payroll record from the database.
            while (rs.next()) {

                // Adds the retrieved values to the JTable.
                tableModel.addRow(new Object[]{
                    rs.getString("employeeID"),
                    rs.getDate("pay_date"),
                    rs.getString("pay_period"),
                    rs.getBigDecimal("daily_rate"),
                    rs.getInt("days_worked"),
                    rs.getBigDecimal("basic_salary"),
                    rs.getBigDecimal("overtime_pay"),
                    rs.getBigDecimal("gross_salary"),
                    rs.getBigDecimal("deductions"),
                    rs.getBigDecimal("net_salary"),
                    rs.getString("payment_status")
                });
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // GET EMPLOYEE ID FROM TEXT FIELD
    private String getEmployeeID() {

        // Gets the Employee ID entered by the user.
        String employeeID = pv.txtEmployeeID.getText().trim();

        // Returns null if the field is empty.
        return employeeID.isEmpty() ? null : employeeID;
    }

    // FILL FIELDS FROM SELECTED ROW
    private void fillFieldsFromSelectedRow() {

        int row = pv.payrollTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        // Column 0 = Employee ID
        pv.txtEmployeeID.setText(
                tableModel.getValueAt(row, 0).toString()
        );

        // Column 1 = Pay Date
        pv.jTextField2.setText(
                tableModel.getValueAt(row, 1).toString()
        );

        // Column 2 = Pay Period
        pv.jTextField3.setText(
                tableModel.getValueAt(row, 2).toString()
        );

        // Column 3 = Daily Rate
        pv.jTextField4.setText(
                tableModel.getValueAt(row, 3).toString()
        );

        // Column 4 = Days Worked
        pv.jTextField5.setText(
                tableModel.getValueAt(row, 4).toString()
        );

        // Column 6 = Overtime Pay
        pv.jTextField6.setText(
                tableModel.getValueAt(row, 6).toString()
        );

        // Column 8 = Deductions
        pv.jTextField7.setText(
                tableModel.getValueAt(row, 8).toString()
        );

        // Column 10 = Payment Status
        pv.jTextField8.setText(
                tableModel.getValueAt(row, 10).toString()
        );
    }

    // GET FORM DETAILS
    private PayrollDetails getFormDetails() {

        // Gets Employee ID from the JTextField.
        String employeeID = getEmployeeID();

        if (employeeID == null) {

            JOptionPane.showMessageDialog(
                    pv, "Please enter an Employee ID."
            );

            return null;
        }

        try {

            String payDateText = pv.jTextField2.getText().trim();
            String payPeriod = pv.jTextField3.getText().trim();
            String dailyRateText = pv.jTextField4.getText().trim();
            String daysWorkedText = pv.jTextField5.getText().trim();
            String overtimeText = pv.jTextField6.getText().trim();
            String deductionsText = pv.jTextField7.getText().trim();
            String paymentStatus = pv.jTextField8.getText().trim();

            // Checks whether required fields are empty.
            if (payDateText.isEmpty()
                    || payPeriod.isEmpty()
                    || dailyRateText.isEmpty()
                    || daysWorkedText.isEmpty()
                    || overtimeText.isEmpty()
                    || deductionsText.isEmpty()
                    || paymentStatus.isEmpty()) {

                JOptionPane.showMessageDialog(
                        pv, "Please fill in all payroll fields."
                );

                return null;
            }

            // Converts text values into their correct data types.
            LocalDate payDate = LocalDate.parse(payDateText);

            BigDecimal dailyRate = new BigDecimal(dailyRateText);
            int daysWorked = Integer.parseInt(daysWorkedText);
            BigDecimal overtime = new BigDecimal(overtimeText);
            BigDecimal deductions = new BigDecimal(deductionsText);

            // Prevents negative payroll values.
            if (dailyRate.compareTo(BigDecimal.ZERO) < 0
                    || daysWorked < 0
                    || overtime.compareTo(BigDecimal.ZERO) < 0
                    || deductions.compareTo(BigDecimal.ZERO) < 0) {

                JOptionPane.showMessageDialog(
                        pv, "Payroll values cannot be negative."
                );

                return null;
            }

            // CALCULATE SALARY

            // Basic Salary = Daily Rate multiplied by Days Worked.
            BigDecimal basicSalary = dailyRate
                    .multiply(BigDecimal.valueOf(daysWorked))
                    .setScale(2, RoundingMode.HALF_UP);

            // Gross Salary = Basic Salary plus Overtime Pay.
            BigDecimal grossSalary = basicSalary
                    .add(overtime)
                    .setScale(2, RoundingMode.HALF_UP);

            // Net Salary = Gross Salary minus Deductions.
            BigDecimal netSalary = grossSalary
                    .subtract(deductions)
                    .setScale(2, RoundingMode.HALF_UP);

            // Deductions cannot be greater than Gross Salary.
            if (deductions.compareTo(grossSalary) > 0) {

                JOptionPane.showMessageDialog(
                        pv, "Deductions cannot exceed gross salary."
                );

                return null;
            }

            // Creates a PayrollDetails model object.
            PayrollDetails p = new PayrollDetails();

            // Stores form values in the model.
            p.setEmployeeID(employeeID);
            p.setPay_date(payDate);
            p.setPay_period(payPeriod);
            p.setDaily_rate(dailyRate);
            p.setDays_worked(daysWorked);
            p.setBasic_salary(basicSalary);
            p.setOvertime_pay(overtime);
            p.setGross_salary(grossSalary);
            p.setDeductions(deductions);
            p.setNet_salary(netSalary);
            p.setPayment_status(paymentStatus);

            return p;

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    pv, "Please enter valid numbers for payroll amounts "
                    + "and days worked."
            );

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    pv, "Pay date must use YYYY-MM-DD format."
            );
        }

        return null;
    }

    // CLEAR FIELDS
    private void clearFields() {

        pv.txtEmployeeID.setText("");
        pv.jTextField2.setText("");
        pv.jTextField3.setText("");
        pv.jTextField4.setText("");
        pv.jTextField5.setText("");
        pv.jTextField6.setText("");
        pv.jTextField7.setText("");
        pv.jTextField8.setText("");

        // Removes selected JTable row.
        pv.payrollTable.clearSelection();
    }

    // ERROR MESSAGE
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                pv,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // BUTTON EVENTS
    public class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            // REFRESH
            if (source == pv.refreshBTN3) {

                loadPayrollTable();
                clearFields();

                JOptionPane.showMessageDialog(
                        pv, "Payroll table refreshed!"
                );

                return;
            }

            // READ
            if (source == pv.readBTN3) {

                loadPayrollTable();

                return;
            }

            // SAVE
            if (source == pv.saveBTN3) {

                PayrollDetails p = getFormDetails();

                if (p != null && PayrollDAO.save(p)) {

                    loadPayrollTable();
                    clearFields();
                }

                return;
            }

            // UPDATE
            if (source == pv.updateBTN3) {

                int row = pv.payrollTable.getSelectedRow();

                if (row == -1) {
                    JOptionPane.showMessageDialog(
                            pv, "Select a payroll row first."
                    );
                    return;
                }

                // Gets the original record identification values.
                String oldEmployeeID =
                        tableModel.getValueAt(row, 0).toString();

                LocalDate oldPayDate =
                        LocalDate.parse(
                                tableModel.getValueAt(row, 1).toString()
                        );

                String oldPayPeriod =
                        tableModel.getValueAt(row, 2).toString();

                PayrollDetails p = getFormDetails();

                if (p == null) {
                    return;
                }

                int choice = JOptionPane.showConfirmDialog(
                        pv,
                        "Update the selected payroll record?",
                        "Confirm Update",
                        JOptionPane.YES_NO_OPTION
                );

                if (choice == JOptionPane.YES_OPTION) {

                    // DAO updates the selected payroll record.
                    if (PayrollDAO.update(
                            oldEmployeeID,
                            oldPayDate,
                            oldPayPeriod,
                            p)) {

                        loadPayrollTable();
                        clearFields();
                    }
                }

                return;
            }

            // DELETE
            if (source == pv.deleteBTN3) {

                int row = pv.payrollTable.getSelectedRow();

                if (row == -1) {
                    JOptionPane.showMessageDialog(
                            pv, "Select a payroll row first."
                    );
                    return;
                }

                // Gets the selected record identification values.
                String employeeID =
                        tableModel.getValueAt(row, 0).toString();

                LocalDate payDate =
                        LocalDate.parse(
                                tableModel.getValueAt(row, 1).toString()
                        );

                String payPeriod =
                        tableModel.getValueAt(row, 2).toString();

                int choice = JOptionPane.showConfirmDialog(
                        pv,
                        "Delete the selected payroll record?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {

                    // DAO deletes the selected payroll record.
                    if (PayrollDAO.delete(
                            employeeID, payDate, payPeriod)) {

                        loadPayrollTable();
                        clearFields();
                    }
                }
            }
        }
    }
}
