
package payroll;

import db.DB;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PayrollDAO {

    // SAVE PAYROLL RECORD
    public static boolean save(PayrollDetails p) {

        String sql = "INSERT INTO payroll "
                + "(employeeID, pay_date, pay_period, daily_rate, "
                + "days_worked, basic_salary, overtime_pay, "
                + "gross_salary, deductions, net_salary, payment_status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getEmployeeID());
            ps.setDate(2, Date.valueOf(p.getPay_date()));
            ps.setString(3, p.getPay_period());
            ps.setBigDecimal(4, p.getDaily_rate());
            ps.setInt(5, p.getDays_worked());
            ps.setBigDecimal(6, p.getBasic_salary());
            ps.setBigDecimal(7, p.getOvertime_pay());
            ps.setBigDecimal(8, p.getGross_salary());
            ps.setBigDecimal(9, p.getDeductions());
            ps.setBigDecimal(10, p.getNet_salary());
            ps.setString(11, p.getPayment_status());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(
                    null, "Payroll record saved successfully!"
            );

            return true;

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error saving payroll: " + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return false;
        }
    }

    // LOAD PAYROLL TABLE
    public static void loadTable(DefaultTableModel tableModel) {

        tableModel.setRowCount(0);

        String sql = "SELECT employeeID, pay_date, pay_period, "
                + "daily_rate, days_worked, basic_salary, "
                + "overtime_pay, gross_salary, deductions, "
                + "net_salary, payment_status "
                + "FROM payroll "
                + "ORDER BY pay_date DESC, employeeID";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                tableModel.addRow(new Object[]{
                    rs.getString("employeeID"),
                    rs.getDate("pay_date"),
                    rs.getString("pay_period"),
                    rs.getBigDecimal("daily_rate"),
                    rs.getInt("days_worked"),
                    rs.getBigDecimal("basic_salary"),
                    rs.getBigDecimal("overtime_pay"),
                    rs.getBigDecimal("gross_salary"),
                    rs.getBigDecimal("deductions"),
                    rs.getBigDecimal("net_salary"),
                    rs.getString("payment_status")
                });
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error loading payroll: " + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // UPDATE PAYROLL RECORD
    // Uses the original employeeID, pay_date, and pay_period
    public static boolean update(
            String oldEmployeeID,
            LocalDate oldPayDate,
            String oldPayPeriod,
            PayrollDetails p) {

        String sql = "UPDATE payroll SET "
                + "employeeID = ?, "
                + "pay_date = ?, "
                + "pay_period = ?, "
                + "daily_rate = ?, "
                + "days_worked = ?, "
                + "basic_salary = ?, "
                + "overtime_pay = ?, "
                + "gross_salary = ?, "
                + "deductions = ?, "
                + "net_salary = ?, "
                + "payment_status = ? "
                + "WHERE employeeID = ? "
                + "AND pay_date = ? "
                + "AND pay_period = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getEmployeeID());
            ps.setDate(2, Date.valueOf(p.getPay_date()));
            ps.setString(3, p.getPay_period());
            ps.setBigDecimal(4, p.getDaily_rate());
            ps.setInt(5, p.getDays_worked());
            ps.setBigDecimal(6, p.getBasic_salary());
            ps.setBigDecimal(7, p.getOvertime_pay());
            ps.setBigDecimal(8, p.getGross_salary());
            ps.setBigDecimal(9, p.getDeductions());
            ps.setBigDecimal(10, p.getNet_salary());
            ps.setString(11, p.getPayment_status());

            // Original record identification
            ps.setString(12, oldEmployeeID);
            ps.setDate(13, Date.valueOf(oldPayDate));
            ps.setString(14, oldPayPeriod);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                JOptionPane.showMessageDialog(
                        null, "Payroll record updated successfully!"
                );

                return true;
            }

            JOptionPane.showMessageDialog(
                    null, "No matching payroll record found."
            );

            return false;

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error updating payroll: " + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return false;
        }
    }

    // DELETE PAYROLL RECORD
    public static boolean delete(
            String employeeID,
            LocalDate payDate,
            String payPeriod) {

        String sql = "DELETE FROM payroll "
                + "WHERE employeeID = ? "
                + "AND pay_date = ? "
                + "AND pay_period = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, employeeID);
            ps.setDate(2, Date.valueOf(payDate));
            ps.setString(3, payPeriod);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                JOptionPane.showMessageDialog(
                        null, "Payroll record deleted successfully!"
                );

                return true;
            }

            JOptionPane.showMessageDialog(
                    null, "No matching payroll record found."
            );

            return false;

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error deleting payroll: " + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return false;
        }
    }
}
